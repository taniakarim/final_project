<?php
    require_once "../libraries/functions.php";
    $user = isLoggedIn() ? getUserById(getLoggedUser()) : null;

    $categoryKey = isCategory($_REQUEST['category']) ? $_REQUEST['category'] : '';

    if(empty($categoryKey)) {
        header("location: index.php");
        exit;
    }

    $category = getCategoryByKey($categoryKey);
    $products = getProductsByCategory($categoryKey);
?>
<!DOCTYPE html>
<html>
<head>
    <title>KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <?php if(!empty($user)) { if(isCustomer($user)) { ?>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="cart.php">Cart</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                    <?php } else {?>
                    <td>
                        <a href="system">System</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="system/profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                    <?php } } else {?>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="login.php">Login</a>
                    </td>
                    <td>
                        <a href="register.php">Register</a>
                    </td>
                    <?php } ?>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <form action="search.php" method="get">
                <table class="search-box">
                    <tbody>
                    <tr>
                        <td>
                            <input type="hidden" name="category" value="<?php echo $categoryKey ?>">
                            <input type="text" name="search" placeholder="Search for products (e.g. eggs, milk, potato)">
                        </td>
                        <td>
                            <button type="submit">Search</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            <table>
                <tr>
                    <td><img src="../assets/images/category/<?php echo $category['image'] ?>" width="30" height="30"></td>
                    <td><h3 class="title"><?php echo $category['name'] ?></h3></td>
                </tr>
            </table>
            <?php if(($total = count($products))>0) { $col = 1; $printed = 0;?>
                <table class="product-list">
                    <tbody>
                    <tr>
                        <?php foreach ($products as $product) { ?>
                            <?php if($col>4) {echo "</tr><tr>"; $col = 1; } $col++; $printed++?>
                            <td>
                                <a href="product.php?product=<?php echo $product['id']?>">
                                    <img src="../assets/images/<?php echo !empty($product['image']) ? "uploads/".$product['image'] : "product-default.jpg"; ?>" width="265" height="200">
                                    <span class="title"><?php echo $product['name'] ?></span>
                                    <span class="price">৳ <?php echo $product['price'] ?></span>
                                    <?php  ?>
                                    <?php if($product['active']==1 && ($user==null || isCustomer($user))) { ?>
                                    <form action="cart.php?add" method="post">
                                        <input type="hidden" name="product" value="<?php echo $product['id']?>">
                                        <table>
                                            <tbody>
                                            <tr>
                                                <td onclick="event.preventDefault()">
                                                    <input type="number" min="1" value="1" name="quantity">
                                                </td>
                                                <td>
                                                    <button type="submit">Add to Cart</button>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </form>
                                    <?php } ?>
                                </a>
                            </td>
                            <?php if($printed==$total && !($col>4)) {
                                $need = 5-$col;
                                echo '<td colspan="'.$need.'"></td>';
                            } ?>
                        <?php } ?>
                    </tr>
                    </tbody>
                </table>
            <?php } else { ?>
                <h3 class="title">No Products Found In This Category</h3>
            <?php } ?>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>