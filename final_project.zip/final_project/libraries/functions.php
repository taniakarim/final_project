<?php
session_start();

require_once "database.php";

function isLoggedIn() {
    return isset($_SESSION['logged_in_user']) && !empty($_SESSION['logged_in_user']);
}

function getLoggedUser() {
    return $_SESSION['logged_in_user'];
}

function setLoggedUser($id) {
    $_SESSION['logged_in_user'] = $id;
}

function removeLoggedUser() {
    unset($_SESSION['logged_in_user']);
}

function isCustomer($user) {
    return $user['role'] == 'customer';
}

function isAdmin($user) {
    return $user['role'] == 'admin';
}

function isEmployee($user) {
    return $user['role'] == 'employee';
}

function isManager($user) {
    return $user['role'] == 'manager';
}

function hasAccess($target, $user) {
    // Roles
    // admin , manager, employee, customer
    $access = array(
        'addproduct' => array(
            'admin', 'manager'
        ),
        'listproduct' => array(
            'admin', 'manager', 'employee'
        ),
        'editproduct' => array(
            'admin', 'manager'
        ),
        'deactiveproduct' => array(
            'admin', 'manager'
        ),
        'dashboard' => array(
            'admin', 'manager', 'employee'
        ),
        'listcoupons' => array(
            'admin', 'manager', 'employee'
        ),
        'addcoupon' => array(
            'admin', 'manager'
        ),
        'editcoupon' => array(
            'admin', 'manager'
        ),
        'deletecoupon' => array(
            'admin', 'manager'
        ),
        'listorders' => array(
            'admin', 'manager', 'employee'
        ),
        'deleteorder' => array(
            'admin', 'manager'
        ),
        'changeorderstatus' => array(
            'admin', 'manager', 'employee'
        ),
        'vieworderdetails' => array(
            'admin', 'manager', 'employee'
        ),
        'listmanagers' => array(
            'admin'
        ),
        'addmanager' => array(
            'admin'
        ),
        'updatemanager' => array(
            'admin'
        ),
        'deletemanager' => array(
            'admin'
        ),
        'listemployees' => array(
            'admin', 'manager'
        ),
        'addemployee' => array(
            'admin'
        ),
        'updateemployee' => array(
            'admin', 'manager'
        ),
        'deleteemployee' => array(
            'admin'
        ),
        'listcustomers' => array(
            'admin', 'manager', 'employee'
        ),
        'updatecustomer' => array(
            'admin', 'manager', 'employee'
        ),
        'deletecustomer' => array(
            'admin', 'manager'
        )
    );

    return in_array($user['role'], isset($access[$target]) ? $access[$target] : array());
}

function productCategories() {
    return array(
        "fruits_vegetables" => array(
            "name" => "Fruits and Vegetables",
            "image" => "fruits.png"
        ),
        "meat_fish" => array(
            "name" => "Meat and Fish",
            "image" => "fish.png"
        ),
        "cooking" => array(
            "name" => "Cooking",
            "image" => "cooking.png"
        ),
        "beverage" => array(
            "name" => "Beverages",
            "image" => "beverage.png"
        ),
        "home_cleaning" => array(
            "name" => "Home and Cleaning",
            "image" => "cleaning.png"
        ),
        "pest_control" => array(
            "name" => "Pest Control",
            "image" => "pestcontrol.png"
        ),
        "office" => array(
            "name" => "Office Products",
            "image" => "office.png"
        ),
        "beauty" => array(
            "name" => "Beauty Products",
            "image" => "beauty.png"
        ),
        "health" => array(
            "name" => "Health Products",
            "image" => "health.png"
        ),
        "pet_care" => array(
            "name" => "Pet Care",
            "image" => "petcare.png"
        ),
        "home_appliance" => array(
            "name" => "Home Appliances",
            "image" => "homeappliance.png"
        ),
        "baby_care" => array(
            "name" => "Baby Care",
            "image" => "babycare.png"
        )
    );
}

function isCategory($category) {
    $categories = array_keys(productCategories());
    return in_array($category, $categories);
}

function getCategoryNameByKey($key) {
    $categories = productCategories();
    return isset($categories[$key]) ? $categories[$key]['name'] : '';
}

function getCategoryByKey($key) {
    $categories = productCategories();
    return isset($categories[$key]) ? $categories[$key] : array('name' => 'Unknown', 'image' => 'unknown.png');
}

function randString($length = 10)
{
    $charSet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $generated = '';
    for ($i = 0; $i < $length; $i++) {
        $generated .= $charSet[rand(0, strlen($charSet) - 1)];
    }
    return $generated;
}

function generateNewFileName($file)
{
    $filename = null;

    if(isset($file['name']) && !empty($file['name']))
    {
        if($ext = pathinfo($file['name'], PATHINFO_EXTENSION))
        {
            $filename = md5(time().randString()) . '.' . $ext;
        }
    }

    return $filename;
}

function removeFile($file) {
    $directory = realpath(dirname(__DIR__).'/assets/images/uploads/');
    $path = $directory .'/'. $file;

    if(file_exists($path)) {
        unlink($path);
    }
}

function uploadFile($file)
{
    $filename = '';

    if(isset($file['tmp_name']) && !empty($file['tmp_name']))
    {
        if($filename = generateNewFileName($file))
        {
            $directory = realpath(dirname(__DIR__).'/assets/images/uploads/');
            $path = $directory .'/'. $filename;

            if(is_dir($directory) && !file_exists($path))
            {
                if(!move_uploaded_file($file['tmp_name'], $path))
                {
                    $filename = '';
                }
            }
        }

    }

    return $filename;
}

function initiateCart() {
    if(!isset($_SESSION['cart_products'])) {
        $_SESSION['cart_products'] = array(
            'products' => array(),
            'discount' => array(
                'code' => '',
                'amount' => 0
            )
        );
    }
}

function emptyCart() {
    unset($_SESSION['cart_products']);
    initiateCart();
}

function getCart() {
    initiateCart();
    return $_SESSION['cart_products'];
}

function addToCart($productId, $quantity) {
    initiateCart();

    if(isset($_SESSION['cart_products']['products'][$productId])) {
        $_SESSION['cart_products']['products'][$productId] += $quantity;
    } else {
        $_SESSION['cart_products']['products'][$productId] = $quantity;
    }
}

function removeFromCart($productId) {
    initiateCart();

    if(isset($_SESSION['cart_products']['products'][$productId])) {
        clearDiscount();
        unset($_SESSION['cart_products']['products'][$productId]);
    }

}

function updateCartProductQuantity($productId, $quantity) {
    initiateCart();

    if(isset($_SESSION['cart_products']['products'][$productId])) {
        clearDiscount();
        $_SESSION['cart_products']['products'][$productId] = $quantity;
    }
}

function clearDiscount() {
    initiateCart();
    $_SESSION['cart_products']['discount'] = array(
        'amount' => 0,
        'code' => ''
    );
}

function applyDiscountToCart($discount, $code) {
    initiateCart();
    $_SESSION['cart_products']['discount'] = array(
        'amount' => $discount,
        'code' => $code
    );
}

function calculateCartTotal() {
    $total = 0;
    initiateCart();
    foreach($_SESSION['cart_products']['products'] as $productId => $quantity) {
        $product = getProductById($productId);
        $total += $product['price']*$quantity;
    }
    return $total;
}
