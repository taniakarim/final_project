<?php
    require_once "../libraries/functions.php";
    $user = isLoggedIn() ? getUserById(getLoggedUser()) : null;

    $productId = $_REQUEST['product'];

    if(empty($productId) || empty($product = getProductById($productId))) {
        header("location: index.php");
        exit;
    }

    $category = getCategoryByKey($product['category']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <?php if(!empty($user)) { if(isCustomer($user)) { ?>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="cart.php">Cart</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                    <?php } else {?>
                    <td>
                        <a href="system">System</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="system/profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                    <?php } } else {?>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="login.php">Login</a>
                    </td>
                    <td>
                        <a href="register.php">Register</a>
                    </td>
                    <?php } ?>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <table>
                <tr>
                    <td><img src="../assets/images/category/<?php echo $category['image'] ?>" width="30" height="30"></td>
                    <td><h3 class="title"><?php echo $category['name'] ?></h3></td>
                </tr>
            </table>
            <table class="product-details">
                <tbody>
                    <tr>
                        <td><img src="../assets/images/<?php echo !empty($product['image']) ? "uploads/".$product['image'] : "product-default.jpg"; ?>" width="480" height="362"></td>
                        <td>
                            <h3 class="title"><?php echo $product['name'] ?></h3>
                            <span class="price">৳ <?php echo $product['price'] ?></span>
                            <?php if($product['active']==1 && ($user==null || isCustomer($user))) { ?>
                            <form action="cart.php?add" method="post">
                                <input type="hidden" name="product" value="<?php echo $product['id'] ?>">
                                <table>
                                    <tbody>
                                    <tr>
                                        <td>
                                            <input type="number" min="1" value="1" name="quantity">
                                        </td>
                                        <td>
                                            <button type="submit">Add to Cart</button>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </form>
                            <?php } ?>
                            <p class="product-description mb-0">
                                <?php echo $product['details'] ?>
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>