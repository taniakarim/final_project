<?php
    require_once "../libraries/functions.php";

    if(!isLoggedIn()) {
        header("location: login.php");
        exit;
    }

    $user =  getUserById(getLoggedUser());

    if(empty($user) || !isCustomer($user)) {
        header("location: index.php");
        exit;
    }

    $errors = array();

    // Add Product to Cart
    if(isset($_REQUEST['add']) && isset($_POST['product']) && isset($_POST['quantity'])) {
        $product = getProductById($_POST['product']);
        $quantity = $_POST['quantity'];
        if(!empty($product) && $product['active']==1) {
            if($quantity>0) {
                addToCart($product['id'], $quantity);
                header("location: cart.php");
                exit;
            } else {
                $errors[] = "Quantity must be 1 or more";
            }
        } else {
            $errors[] = "Product not found";
        }
    }

    // Change Product Quantity
    if(isset($_REQUEST['quantitychange']) && isset($_POST['product']) && isset($_POST['quantity'])) {
        $product = getProductById($_POST['product']);
        $quantity = $_POST['quantity'];
        if(!empty($product)) {
            if($quantity>0) {
                updateCartProductQuantity($product['id'], $quantity);
                header("location: cart.php");
                exit;
            } else {
                $errors[] = "Quantity must be 1 or more";
            }
        } else {
            $errors[] = "Product not found";
        }
    }

    // Remove Product from Cart
    if(isset($_REQUEST['removeproduct']) && isset($_REQUEST['product'])) {
        $productId = $_REQUEST['product'];
        if(!empty($productId)) {
            removeFromCart($productId);
            header("location: cart.php");
            exit;
        } else {
            $errors[] = "Product not found";
        }
    }

    // Apply Discount
    if(isset($_REQUEST['applycoupon']) && isset($_POST['code'])) {
        $coupon = getCouponByCode($_POST['code']);
        if(!empty($coupon)) {
            $total = calculateCartTotal();
            $min = (0.6*$coupon['discount'])+$coupon['discount'];
            if($total>=$min) {
                applyDiscountToCart($coupon['discount'], $coupon['code']);
                header("location: cart.php");
                exit;
            } else {
                $errors[] = "Minimum Order Amount for this coupon is {$min}";
            }
        } else {
            $errors[] = "Coupon not found";
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <table>
                <tr>
                    <td><img src="../assets/images/grocery-cart.png" width="30" height="30"></td>
                    <td><h3 class="title">Cart Items</h3></td>
                </tr>
            </table>
            <?php if (!empty($errors)) { ?>
                <fieldset class="error">
                    <legend>Errors</legend>
                    <ul>
                        <?php foreach ($errors as $error) { ?>
                            <li><?php echo $error ?></li>
                        <?php } ?>
                    </ul>
                </fieldset>
            <?php } ?>
            <?php
                $cart = getCart();
                $cartProducts = $cart['products'];
                $discount = $cart['discount']['amount'];
                $subTotal = 0;
                $grandTotal = 0;

                if(count($cartProducts)>0) { ?>
                <table class="cart-details">
                    <thead>
                    <tr>
                        <th colspan="3">Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                    </thead>
                    <tbody>
                <?php
                foreach ($cartProducts as $productId=>$quantity) {
                    $product = getProductById($productId);
                    $total = $product['price']*$quantity;
                    $subTotal += $total;
                    ?>
                    <tr>
                        <td><a href="cart.php?removeproduct&product=<?php echo $product['id'] ?>"><img src="../assets/images/x-button-16.png"></a></td>
                        <td><img src="../assets/images/<?php echo !empty($product['image']) ? "uploads/".$product['image'] : "product-default.jpg"; ?>" height="50" width="66"></td>
                        <td><?php echo $product['name'] ?></td>
                        <td>
                            <form action="cart.php?quantitychange" method="post">
                                <input name="product" type="hidden" value="<?php echo $product['id'] ?>">
                                <input name="quantity" type="number" min="1" onchange="changeQuantity(this)" value="<?php echo $quantity ?>">
                            </form>
                        </td>
                        <td>৳ <?php echo $product['price'] ?></td>
                        <td><?php echo number_format($total, 2, ".", "") ?></td>
                    </tr>
                <?php } ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th colspan="4" rowspan="3">
                            <?php if(!empty($cart['discount']['code'])) { ?>
                                <h2 class="title" align="center">Applied Coupon Code: <?php echo $cart['discount']['code'] ?></h2>
                            <?php } else { ?>
                            <form class="coupon" action="cart.php?applycoupon" method="post">
                                <table>
                                    <tr>
                                        <td>
                                            <div class="input-field">
                                                <input type="text" name="code" placeholder="Type A Coupon Code Here">
                                            </div>
                                        </td>
                                        <td>
                                            <button type="submit">Apply</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                            <?php } ?>
                        </th>
                        <th>
                            Sub Total
                        </th>
                        <th>
                            <?php echo number_format($subTotal, 2, ".", "") ?>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            Discount
                        </th>
                        <th>
                            <?php echo number_format($discount, 2, ".", "") ?>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            Grand Total
                        </th>
                        <th>
                            <?php $grandTotal = $subTotal - $discount; echo number_format($grandTotal, 2, ".", "") ?>
                        </th>
                    </tr>
                    </tfoot>
                </table>
                <a href="checkout.php" class="checkout-proceed">Proceed to Checkout</a>
            <?php } else { ?>
                <h3 class="title">Currently you've no products in the cart</h3>
            <?php } ?>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
<script type="text/javascript">
    function changeQuantity(element) {
        element.parentNode.submit();
    }
</script>
</body>
</html>