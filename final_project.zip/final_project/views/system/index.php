<?php
require_once "../../libraries/functions.php";
if(!isLoggedIn()) {
    header("location: ../login.php");
    exit;
}

$user = getUserById(getLoggedUser());

if(empty($user) || !hasAccess("dashboard", $user)) {
    header("location: ../index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <td>
                        <a href="../">Shop</a>
                    </td>
                    <td>
                        <a href="../logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="profile.php"><?php echo $user["firstName"] ?></a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <table class="system">
                <tbody>
                <tr>
                    <td>
                        <?php include_once "../shared/sidemenu.php" ?>
                    </td>
                    <td>
                        <h3 class="title mt-0">Order Statistics</h3>
                        <hr>
                        <table>
                            <tr>
                                <td>Today's Orders</td><td> : </td><td> <?php echo countToDaysOrders() ?></td>
                            </tr>
                            <tr>
                                <td>Today's Order Amount</td><td> : </td><td> <?php echo number_format(sumToDaysOrders(), 2, ".", "") . " BDT" ?></td>
                            </tr>
                            <tr>
                                <td>Total Orders</td><td> : </td><td> <?php echo countAllOrders() ?></td>
                            </tr>
                            <tr>
                                <td>Total Order Amount</td><td> : </td><td> <?php echo number_format(sumAllOrders(), 2, ".", "") . " BDT" ?></td>
                            </tr>
                            <tr>
                                <td>Total Pending</td><td> : </td><td> <?php echo countOrdersByStatus(array("pending")) ?></td>
                            </tr>
                            <tr>
                                <td>Total Cancelled</td><td> : </td><td> <?php echo countOrdersByStatus(array("cancelled")) ?></td>
                            </tr>
                            <tr>
                                <td>Total Delivered</td><td> : </td><td> <?php echo countOrdersByStatus(array("delivered")) ?></td>
                            </tr>
                            <tr>
                                <td>Total in Processing</td><td> : </td><td> <?php echo countOrdersByStatus(array("processing", "shipping")) ?></td>
                            </tr>
                        </table>
                        <h3 class="title">Product Statistics</h3>
                        <hr>
                        <table>
                            <tr>
                                <td>Total Products</td><td> : </td><td> <?php echo countTotalProducts() ?></td>
                            </tr>
                            <tr>
                                <td>Active Products</td><td> : </td><td> <?php echo countProductsByActivity() ?></td>
                            </tr>
                            <tr>
                                <td>Inactive Products</td><td> : </td><td> <?php echo countProductsByActivity(0) ?></td>
                            </tr>
                        </table>
                        <h3 class="title">User Statistics</h3>
                        <hr>
                        <table>
                            <tr>
                                <td>Total Managers</td><td> : </td><td> <?php echo countUserByRole("manager") ?></td>
                            </tr>
                            <tr>
                                <td>Total Employees</td><td> : </td><td> <?php echo countUserByRole("employee") ?></td>
                            </tr>
                            <tr>
                                <td>Total Customers</td><td> : </td><td> <?php echo countUserByRole("customer") ?></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>