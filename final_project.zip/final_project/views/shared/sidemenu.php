<?php if(hasAccess("dashboard", $user)) { ?>
<a href="index.php">Dashboard</a>
<?php } ?>
<?php if(hasAccess("addproduct", $user) || hasAccess("listproduct", $user) || hasAccess("editproduct", $user) || hasAccess("deactiveproduct", $user)) { ?>
<a href="products.php">Products</a>
<?php } ?>
<?php if(hasAccess("listorders", $user) || hasAccess("deleteorder", $user) || hasAccess("changeorderstatus", $user) || hasAccess("vieworderdetails", $user)) { ?>
<a href="orders.php">Orders</a>
<?php } ?>
<?php if(hasAccess("listmanagers", $user) || hasAccess("addmanager", $user) || hasAccess("updatemanager", $user) || hasAccess("deletemanager", $user)) { ?>
<a href="managers.php">Managers</a>
<?php } ?>
<?php if(hasAccess("listemployees", $user) || hasAccess("addemployee", $user) || hasAccess("updateemployee", $user) || hasAccess("deleteemployee", $user)) { ?>
<a href="employees.php">Employees</a>
<?php } ?>
<?php if(hasAccess("listcustomers", $user) || hasAccess("updatecustomer", $user) || hasAccess("deletecustomer", $user)) { ?>
<a href="customers.php">Customers</a>
<?php } ?>
<?php if(hasAccess("listcoupons", $user) || hasAccess("addcoupon", $user) || hasAccess("editcoupon", $user) || hasAccess("deletecoupon", $user)) { ?>
<a href="coupons.php">Coupons</a>
<?php } ?>