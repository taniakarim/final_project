<?php
require_once 'functions.php';

function listenXMLHttp()
{
    $response = array(
        'status' => false,
        'message' => 'UNKNOWN REQUEST'
    );

    $handshake = '__AclXMLHttp_';


    if(isset($_POST) && isset($_POST['context']) && isXMLHttp())
    {
        if(function_exists($handshake.$_POST['context']))
        {
            call_user_func_array($handshake.$_POST['context'], array($_POST, &$response));
        }
    }

    respond($response);
}

function __AclXMLHttp_getProducts(array $request, array &$response)
{
    if(isset($request['search']) && !empty($request['search'])) {
        $category = isset($request['category']) ? $request['category'] : '';
        $products = searchProduct($request['search'], $category);
        $user = isLoggedIn() ? getUserById(getLoggedUser()) : null;
        ob_start();
        if(($total = count($products))>0) { $col = 1; $printed = 0;?>
            <table class="product-list">
                <tbody>
                <tr>
                    <?php foreach ($products as $product) { ?>
                        <?php if($col>4) {echo "</tr><tr>"; $col = 1; } $col++; $printed++?>
                        <td>
                            <a href="product.php?product=<?php echo $product['id']?>">
                                <img src="../assets/images/<?php echo !empty($product['image']) ? "uploads/".$product['image'] : "product-default.jpg"; ?>" width="265" height="200">
                                <span class="title"><?php echo $product['name'] ?></span>
                                <span class="price">৳ <?php echo $product['price'] ?></span>
                                <?php  ?>
                                <?php if($product['active']==1 && ($user==null || isCustomer($user))) { ?>
                                <form action="cart.php?add" method="post">
                                    <input type="hidden" name="product" value="<?php echo $product['id']?>">
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td onclick="event.preventDefault()">
                                                <input type="number" min="1" value="1" name="quantity">
                                            </td>
                                            <td>
                                                <button type="submit">Add to Cart</button>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </form>
                                <?php } ?>
                            </a>
                        </td>
                        <?php if($printed==$total && !($col>4)) {
                            $need = 5-$col;
                            echo '<td colspan="'.$need.'"></td>';
                        } ?>
                    <?php } ?>
                </tr>
                </tbody>
            </table>
        <?php } else { ?>
            <tr>
                <td style="width: 100%"><h3 class="title" align="center">No Products Found</h3></td>
            </tr>
        <?php }
        $response["status"] = true;
        $response['message'] = ob_get_clean();
    }
    else
    {
        $response['message'] = "Please Insert a Keyword to Search";
    }
}

function respond($response)
{
    header('Content-Type: application/json');
    echo json_encode($response);
}

function isXMLHttp()
{
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}
