<?php
    require_once "../libraries/functions.php";
    $user = isLoggedIn() ? getUserById(getLoggedUser()) : null;

    if(empty($user) || !isCustomer($user)) {
        header("location: index.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="cart.php">Cart</a>
                    </td>
                    <td>
                        <a href="logout.php">Logout</a>
                    </td>
                    <td>
                        <a href="profile.php"><?php echo $user['firstName'] ?></a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <table class="system">
                <tbody>
                    <tr>
                        <td>
                            <a class="active" href="javascript:void(0)">Profile</a>
                            <a href="orders.php">My Orders</a>
                        </td>
                        <td>
                            <h3 class="title mt-0">Your Information's</h3>
                            <hr>
                            <table>
                                <tr>
                                    <td>User Name</td>
                                    <td>:</td>
                                    <td><?php echo $user['username'] ?></td>
                                </tr>
                                <tr>
                                    <td>First Name</td>
                                    <td>:</td>
                                    <td><?php echo $user['firstName'] ?></td>
                                </tr>
                                <tr>
                                    <td>First Name</td>
                                    <td>:</td>
                                    <td><?php echo $user['lastName'] ?></td>
                                </tr>
                                <tr>
                                    <td>Mobile No</td>
                                    <td>:</td>
                                    <td><?php echo $user['mobile'] ?></td>
                                </tr>
                            </table>
                            <div class="mt-5">
                                <a href="updateprofile.php" class="button-default inline-block">Update Information</a>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>