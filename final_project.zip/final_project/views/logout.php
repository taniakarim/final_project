<?php
    require_once "../libraries/functions.php";
    removeLoggedUser();
    header("location: login.php");