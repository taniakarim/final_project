<?php
require_once ('../libraries/functions.php') ;

if(isLoggedIn()) {
    header("location: index.php");
    exit;
}

$errors = array();

if(isset($_POST['register'])){
    $username   =   $_POST['username'];
    $firstName =   $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];

    if(empty($username)) {
        $errors[] = "User Name is required";
    }
    else if(!empty(getUserByUsername($username))) {
        $errors[] = "User Name is already taken";
    }

    if(empty($firstName)) {
        $errors[] = "First Name is required";
    }

    if(empty($lastName)) {
        $errors[] = "Last Name is required";
    }

    if(empty($password) || empty($repassword)) {
        $errors[] = "Password and Confirm Password is required";
    }
    else if($password!=$repassword) {
        $errors[] = "Password and Confirm Password doesn't match";
    }

    if(empty($errors)) {
        if(addUser(array(
            'username' => $username,
            'password' => $password,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'mobile' => $mobile,
            'role' => 'customer',
            'registered' => date("Y-m-d H:i:s")
        ))) {
            header('location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register - KenaKata Super Shop</title>
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<table class="customer-body">
    <tbody>
    <tr class="customer-header">
        <td><img src="../assets/images/logo.png" width="236" height="60"></td>
        <td>
            <table class="header-button">
                <tbody>
                <tr>
                    <td>
                        <a href="./">Home</a>
                    </td>
                    <td>
                        <a href="login.php">Login</a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    <tr class="customer-main-body">
        <td colspan="2">
            <div class="login-box">
                <div class="login-header">
                    <img src="../assets/images/register.png">
                    <h2>Register as a Customer</h2>
                </div>
                <form method="post" onsubmit="return validation()">
                    <?php if (!empty($errors)) { ?>
                        <fieldset class="error">
                            <legend>Errors</legend>
                            <ul>
                                <?php foreach ($errors as $error) { ?>
                                    <li><?php echo $error ?></li>
                                <?php } ?>
                            </ul>
                        </fieldset>
                    <?php } ?>
                    <div class="input-field">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" placeholder="Enter User Name">
                    </div>
                    <div class="input-field">
                        <label for="first_name">First Name</label>
                        <input type="text" name="first_name" id="first_name" placeholder="Enter First Name">
                    </div>
                    <div class="input-field">
                        <label for="last_name">Last Name</label>
                        <input type="text" name="last_name" id="last_name" placeholder="Enter Last Name">
                    </div>
                    <div class="input-field">
                        <label for="mobile">Mobile No</label>
                        <input type="text" name="mobile" id="mobile" placeholder="Enter Mobile No">
                    </div>
                    <div class="input-field">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter a new password">
                    </div>
                    <div class="input-field">
                        <label for="repassword">Confirm Password</label>
                        <input type="password" name="repassword" id="repassword" placeholder="Re-Type your password">
                    </div>
                    <div class="input-field mb-0">
                        <button type="submit" class="button-default" name="register">Register</button>
                    </div>
                </form>
            </div>
        </td>
    </tr>
    <tr class="customer-footer">
        <td class="customer-main-body" colspan="2">
            &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
        </td>
    </tr>
    </tbody>
</table>
<script type="text/javascript">
    function validation() {
        var username = document.getElementById('username').value,
            firstName = document.getElementById('first_name').value,
            lastName = document.getElementById('last_name').value,
            password = document.getElementById('password').value,
            repassword = document.getElementById('repassword').value;

        var errors = [];

        if(!username || !(username.length>0)) {
            errors.push('User Name is required');
        }

        if(!firstName || !(firstName.length>0)) {
            errors.push('First Name is required');
        }

        if(!lastName || !(lastName.length>0)) {
            errors.push('Last Name is required');
        }

        if(!password || !repassword || !(password.length>0) || !(repassword.length>0)) {
            errors.push('Password & Confirm Password is required');
        }
        else if(password!=repassword) {
            errors.push('Password & Confirm Password doesn\'t match');
        }

        if(!(errors.length>0)) {
            return true;
        } else {
            alert("Errors Occurred: \n"+errors.join("\n"));
            return false;
        }
    }
</script>
</body>
</html>