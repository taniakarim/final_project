<?php
    header("location: views");