<?php
function getConnection(){
    return mysqli_connect('127.0.0.1','root','','webtech_kenakata_shop');
}

function escapeStrings(&$array) {
    $conn = getConnection();
    foreach ($array as $key=>$value) {
        $array[$key] = mysqli_escape_string($conn, $value);
    }
}

function executeSelect($query) {
    $conn = getConnection();
    $result = mysqli_query($conn, $query);
    $response = array();
    if($result) {
        while($data = mysqli_fetch_assoc($result)){
            array_push($response, $data);
        }
    }

    return $response;
}

function executeInsert($query) {
    $conn = getConnection();

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }

    if(mysqli_query($conn, $query)) {
        return mysqli_insert_id($conn);
    } else {
        echo mysqli_error($conn);
    }



    return false;
}

function executeUpdateDelete($query) {
    $conn = getConnection();
    return mysqli_query($conn, $query);
}

/**
 * @param array $user[
 *      'username',
 *      'password',
 *      'firstName',
 *      'lastName',
 *      'mobile',
 *      'role',
 *      'registered'
 * ]
 * @return bool|int|string
 */
function addUser(array $user) {
    escapeStrings($user);
    $sql = "INSERT INTO `users`(`id`, `username`, `password`, firstName, lastName, `mobile`, `role`, `registered`) 
            VALUES (null,'{$user['username']}','{$user['password']}','{$user['firstName']}','{$user['lastName']}','{$user['mobile']}','{$user['role']}','{$user['registered']}')";
    return executeInsert($sql);
}

/**
 * @param array $product[
 *      'name',
 *      'category',
 *      'details',
 *      'price',
 *      'image'
 * ]
 * @return bool|int|string
 */
function addProduct(array $product) {
    escapeStrings($product);
    $sql = "INSERT INTO `products`(`id`, `name`,`category`, `details`, `price`, `image`, `active`) 
            VALUES (null,'{$product['name']}','{$product['category']}','{$product['details']}',{$product['price']},'{$product['image']}',1)";
    return executeInsert($sql);
}

/**
 * @param array $review[
 *      'userId',
 *      'productId',
 *      'review'
 * ]
 * @return bool|int|string
 */
function addProductReview(array $review) {
    $sql = "INSERT INTO `products_reviews`(`id`, `userId`, `productId`, `review`) 
            VALUES (null,{$review['userId']},{$review['productId']},'{$review['review']}')";
    return executeInsert($sql);
}

/**
 * @param array $coupon[
 *      'code',
 *      'discount'
 * ]
 * @return bool|int|string
 */
function addCoupon(array $coupon) {
    $sql = "INSERT INTO `coupons`(`id`, `code`, `discount`) VALUES (null,'{$coupon['code']}','{$coupon['discount']}')";
    return executeInsert($sql);
}

/**
 * @param array $order[
 *      'userId',
 *      'total',
 *      'discount',
 *      'grandTotal',
 *      'coupon',
 *      'receiver',
 *      'mobile',
 *      'address',
 *      'date',
 *      'status'
 * ]
 * @return bool|int|string
 */
function addOrder(array $order) {
    $sql = "INSERT INTO `orders`(`id`, `userId`, `total`, `discount`, `grandTotal`, `coupon`, `receiver`, `mobile`, `address`, `date`, `status`) 
            VALUES (null,{$order['userId']},{$order['total']},{$order['discount']},{$order['grandTotal']},'{$order['coupon']}','{$order['receiver']}','{$order['mobile']}','{$order['address']}','{$order['date']}','{$order['status']}')";
    return executeInsert($sql);
}

function addOrderProducts($orderId, array $products) {
    $sql = "INSERT INTO `orders_products`(`id`, `orderId`, `productId`, `quantity`) VALUES ";
    foreach ($products as $product=>$quantity) {
        $sql .= "(null, {$orderId}, {$product}, {$quantity}),";
    }
    $sql = rtrim($sql, ",");
    return executeInsert($sql);
}

function getUserByUsername($username) {
    $sql = "SELECT * FROM `users` WHERE `username` = '{$username}'";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getUserById($id) {
    $sql = "SELECT * FROM `users` WHERE `id` = '{$id}'";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getProducts($order="id") {
    $sql = "SELECT * FROM `products` ORDER BY `{$order}` DESC";
    return executeSelect($sql);
}

function getProductsByCategory($category, $active=1, $order="name") {
    $sql = "SELECT * FROM `products` WHERE `category` = '{$category}' AND `active` = {$active} ORDER BY `{$order}` ASC";
    return executeSelect($sql);
}

function getProductById($id) {
    $sql = "SELECT * FROM `products` WHERE `id` = '{$id}'";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getCoupons($order="id") {
    $sql = "SELECT * FROM `coupons` ORDER BY `{$order}` DESC";
    return executeSelect($sql);
}

function countCouponUsed($code) {
    $sql = "SELECT COUNT(*) as `count` FROM `orders` WHERE `coupon` = '{$code}'";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }

    return 0;
}

function getCouponByCode($code) {
    $sql = "SELECT * FROM `coupons` WHERE `code` = '{$code}'";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getCouponById($id) {
    $sql = "SELECT * FROM `coupons` WHERE `id` = '{$id}'";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getOrders($order="date") {
    $sql = "SELECT * FROM `orders` ORDER BY `{$order}` DESC";
    return executeSelect($sql);
}

function getOrdersByUserId($id) {
    $sql = "SELECT * FROM `orders` WHERE `userId` = {$id} ORDER BY `date` DESC";
    return executeSelect($sql);
}

function getOrderById($id) {
    $sql = "SELECT * FROM `orders` WHERE `id` = {$id}";
    $result = executeSelect($sql);
    return !empty($result) && isset($result[0]) ? $result[0] : null;
}

function getOrderProducts($orderId) {
    $sql = "SELECT `products`.*, `orders_products`.`quantity` FROM `products`
            INNER JOIN `orders_products` ON `products`.`id` = `orders_products`.`productId` 
            WHERE `orders_products`.`orderId` = {$orderId} ORDER BY `orders_products`.`id` ASC";
    return executeSelect($sql);
}

/**
 * @param $id
 * @param $status 'pending' | 'processing' | 'shipping' | 'delivered' | 'cancelled'
 * @return bool|mysqli_result
 */
function changeOrderStatus($id, $status) {
    $sql = "UPDATE `orders` SET `status` = '{$status}' WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function removeOrderProcusts($orderId) {
    $sql = "DELETE FROM `orders_products` WHERE `orderId` = {$orderId}";
    return executeUpdateDelete($sql);
}

function removeOrder($id) {
    $sql = "DELETE FROM `orders` WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function updateProduct(array $updates, $id) {
    escapeStrings($updates);
    $sql = "UPDATE `products` SET `name` = '{$updates["name"]}', `details` = '{$updates["details"]}', `category` = '{$updates["category"]}', `price` = {$updates['price']}, `image` = '{$updates['image']}' WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function updateProductActivity($id, $state=0) {
    $sql = "UPDATE `products` SET `active` = {$state} WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function updateCoupon(array $updates, $id) {
    $sql = "UPDATE `coupons` SET `code` = '{$updates['code']}', `discount` = {$updates['discount']} WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function getUsersByRole($role) {
    $sql = "SELECT * FROM `users` WHERE `role` = '{$role}' ORDER BY `id` DESC";
    return executeSelect($sql);
}

function updateUser(array $updates, $id) {
    $sql = "UPDATE `users` SET `username` = '{$updates["username"]}', `password` = '{$updates["password"]}', `firstName` = '{$updates["firstName"]}', `lastName` = '{$updates['lastName']}', `mobile` = '{$updates["mobile"]}' WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function deleteUser($id) {
    $sql = "DELETE FROM `users` WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function deleteCustomerOrders($customerId) {
    $sql = "DELETE FROM `orders_products` WHERE  `orderId` IN ( SELECT `id` FROM `orders` WHERE `userId` = {$customerId} )";
    executeUpdateDelete($sql);
    $sql = "DELETE FROM `orders` WHERE `userId` = {$customerId}";
    return executeUpdateDelete($sql);
}

function deleteCoupon($id) {
    $sql = "DELETE FROM `coupons` WHERE `id` = {$id}";
    return executeUpdateDelete($sql);
}

function countToDaysOrders() {
    $dateStart = date("Y-m-d") . " 00:00:00";
    $dateEnd = date("Y-m-d") . " 23:59:59";
    $sql = "SELECT COUNT(*) as `count` FROM `orders` WHERE `date`>'{$dateStart}' AND `date`<'{$dateEnd}'";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function sumToDaysOrders() {
    $dateStart = date("Y-m-d") . " 00:00:00";
    $dateEnd = date("Y-m-d") . " 23:59:59";
    $sql = "SELECT SUM(`grandTotal`) as `sum` FROM `orders` WHERE `date`>'{$dateStart}' AND `date`<'{$dateEnd}'";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['sum'];
    }
    return 0;
}

function countAllOrders() {
    $sql = "SELECT COUNT(*) as `count` FROM `orders`";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function sumAllOrders() {
    $sql = "SELECT SUM(`grandTotal`) as `sum` FROM `orders`";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['sum'];
    }
    return 0;
}

function countOrdersByStatus(array $status) {
    $sql = "SELECT COUNT(*) as `count` FROM `orders` WHERE `status` IN ('".implode("','", $status)."')";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function countTotalProducts() {
    $sql = "SELECT COUNT(*) as `count` FROM `products`";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function countProductsByActivity($activity=1) {
    $sql = "SELECT COUNT(*) as `count` FROM `products` WHERE `active` = {$activity}";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function countUserByRole($role) {
    $sql = "SELECT COUNT(*) as `count` FROM `users` WHERE `role` = '{$role}'";
    $result = executeSelect($sql);
    if(count($result)>0) {
        return $result[0]['count'];
    }
    return 0;
}

function searchProduct($key, $category="") {
    $sql = "SELECT * FROM  `products` WHERE `name` LIKE '%{$key}%' ";
    if(!empty($category)) {
        $sql .= "AND `category` = '{$category}' ";
    }
    $sql .= "ORDER BY `name` ASC";
    return executeSelect($sql);
}
