<?php
    require_once "../libraries/functions.php";
    $user = isLoggedIn() ? getUserById(getLoggedUser()) : null;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>KenaKata Super Shop</title>
        <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
        <link rel="stylesheet" href="../assets/css/styles.css">
    </head>
    <body>
        <table class="customer-body">
            <tbody>
                <tr class="customer-header">
                    <td><img src="../assets/images/logo.png" width="236" height="60"></td>
                    <td>
                        <table class="header-button">
                            <tbody>
                                <tr>
                                    <?php if(!empty($user)) { if(isCustomer($user)) { ?>
                                    <td>
                                        <a href="cart.php">Cart</a>
                                    </td>
                                    <td>
                                        <a href="logout.php">Logout</a>
                                    </td>
                                    <td>
                                        <a href="profile.php"><?php echo $user['firstName'] ?></a>
                                    </td>
                                    <?php } else {?>
                                    <td>
                                        <a href="system">System</a>
                                    </td>
                                    <td>
                                        <a href="logout.php">Logout</a>
                                    </td>
                                    <td>
                                        <a href="system/profile.php"><?php echo $user['firstName'] ?></a>
                                    </td>
                                    <?php } } else {?>
                                    <td>
                                        <a href="login.php">Login</a>
                                    </td>
                                    <td>
                                        <a href="register.php">Register</a>
                                    </td>
                                    <?php } ?>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr class="customer-main-body">
                    <td colspan="2">
                        <form action="search.php" method="get">
                            <table class="search-box">
                                <tbody>
                                <tr>
                                    <td>
                                        <input type="text" name="search" placeholder="Search for products (e.g. eggs, milk, potato)">
                                    </td>
                                    <td>
                                        <button type="submit">Search</button>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </form>
                        <h3 class="title text-center">Our Product Categories</h3>
                        <table class="product-categories">
                            <tbody>
                                <tr>
                                    <td><a href="category.php?category=fruits_vegetables"><span>Fruits and Vegetables</span><img src="../assets/images/category/fruits.png"></a></td>
                                    <td><a href="category.php?category=meat_fish"><span>Meat and Fish</span><img src="../assets/images/category/fish.png"></a></td>
                                    <td><a href="category.php?category=cooking"><span>Cooking</span><img src="../assets/images/category/cooking.png"></a></td>
                                </tr>
                                <tr>
                                    <td><a href="category.php?category=beverage"><span>Beverages</span><img src="../assets/images/category/beverage.png"></a></td>
                                    <td><a href="category.php?category=home_cleaning"><span>Home and Cleaning</span><img src="../assets/images/category/cleaning.png"></a></td>
                                    <td><a href="category.php?category=pest_control"><span>Pest Control</span><img src="../assets/images/category/pestcontrol.png"></a></td>
                                </tr>
                                <tr>
                                    <td><a href="category.php?category=office"><span>Office Products</span><img src="../assets/images/category/office.png"></a></td>
                                    <td><a href="category.php?category=beauty"><span>Beauty Products</span><img src="../assets/images/category/beauty.png"></a></td>
                                    <td><a href="category.php?category=health"><span>Health Products</span><img src="../assets/images/category/health.png"></a></td>
                                </tr>
                                <tr>
                                    <td><a href="category.php?category=pet_care"><span>Pet Care</span><img src="../assets/images/category/petcare.png"></a></td>
                                    <td><a href="category.php?category=home_appliance"><span>Home Appliances</span><img src="../assets/images/category/homeappliance.png"></a></td>
                                    <td><a href="category.php?category=baby_care"><span>Baby Care</span><img src="../assets/images/category/babycare.png"></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr class="customer-footer">
                    <td class="customer-main-body" colspan="2">
                        &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>