<?php
require_once ('../libraries/functions.php') ;

if(isLoggedIn()) {
    header("location: index.php");
    exit;
}

$errors = array();

if(isset($_POST['login'])){
    $username   =   $_POST['username'];
    $password = $_POST['password'];

    if(empty($username)) {
        $errors[] = "User Name is required";
    }
    else if(empty($user = getUserByUsername($username))) {
        $errors[] = "User Name not matched";
    }

    if(empty($password)) {
        $errors[] = "Password is required";
    }
    else if(!empty($user) && $password!=$user['password']) {
        $errors[] = "Password doesn't matched";
    }

    if(empty($errors)) {
        setLoggedUser($user['id']);
        switch ($user['role']) {
            case 'customer':
                header('location: index.php');
                exit;
                break;
            case 'admin':
            case 'manager':
            case  'employee':
            default:
                header('location: system/index.php');
                exit;
        }

    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login - KenaKata Super Shop</title>
        <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">
        <link rel="stylesheet" href="../assets/css/styles.css">
    </head>
    <body>
        <table class="customer-body">
            <tbody>
            <tr class="customer-header">
                <td><img src="../assets/images/logo.png" width="236" height="60"></td>
                <td>
                    <table class="header-button">
                        <tbody>
                        <tr>
                            <td>
                                <a href="./">Home</a>
                            </td>
                            <td>
                                <a href="register.php">Register</a>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr class="customer-main-body">
                <td colspan="2">
                    <div class="login-box">
                        <div class="login-header">
                            <img src="../assets/images/login.png">
                            <h2>Login to System</h2>
                        </div>
                        <form method="post" onsubmit="return validation()">
                            <?php if (!empty($errors)) { ?>
                                <fieldset class="error">
                                    <legend>Errors</legend>
                                    <ul>
                                        <?php foreach ($errors as $error) { ?>
                                            <li><?php echo $error ?></li>
                                        <?php } ?>
                                    </ul>
                                </fieldset>
                            <?php } ?>
                            <div class="input-field">
                                <label for="username">Username</label>
                                <input type="text" name="username" id="username" placeholder="Enter User Name">
                            </div>
                            <div class="input-field">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" placeholder="Enter User Name">
                            </div>
                            <div class="input-field mb-0">
                                <button type="submit" class="button-default" name="login">Login Here</button>
                            </div>
                        </form>
                    </div>
                </td>
            </tr>
            <tr class="customer-footer">
                <td class="customer-main-body" colspan="2">
                    &copy; 2020 - KenaKata Super Shop<br>All Rights Reserved
                </td>
            </tr>
            </tbody>
        </table>
    </body>
    <script type="text/javascript">
        function validation() {
            var username = document.getElementById('username').value,
                password = document.getElementById('password').value,
                errors = [];

            if(!username || !(username.length>0)) {
                errors.push('User Name is required');
            }

            if(!password || !(password.length>0)) {
                errors.push('Password & Confirm Password is required');
            }

            if(!(errors.length>0)) {
                return true;
            } else {
                alert("Errors Occurred: \n"+errors.join("\n"));
                return false;
            }
        }
    </script>
</html>